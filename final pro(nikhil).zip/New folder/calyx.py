# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 20:50:39 2019

@author: Paavana Sanvi
"""

import cv2
import numpy as np
from matplotlib import pyplot as plt
img1 = cv2.imread('Golden_02_4.JPG')
img = cv2.imread('Golden_02_4.JPG',0)
ret,thresh1 = cv2.threshold(img,25,255,cv2.THRESH_BINARY)
ret,thresh2 = cv2.threshold(img,25,255,cv2.THRESH_BINARY_INV)

kernel = np.ones((25,25),np.uint8)
closing = cv2.morphologyEx(thresh1, cv2.MORPH_CLOSE, kernel)

res=cv2.bitwise_and(img1,img1,mask=closing)
cv2.imshow('hi',thresh1)
cv2.waitKey(0)
cv2.destroyAllWindows()
calyx=cv2.cvtColor(res, cv2.COLOR_BGR2YCrCb)

plt.imshow(calyx[:,:,2],cmap="gray")
plt.title('Chrominance Cb')
plt.show()

Z = calyx[:,:,2].reshape((-1,3))


Z = np.float32(Z)


# define criteria, number of clusters(K) and apply kmeans()
criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
K = 2
ret,label,center=cv2.kmeans(Z,K,None,criteria,10,cv2.KMEANS_RANDOM_CENTERS)

# Now convert back into uint8, and make original image
center = np.uint8(center)
res = center[label.flatten()]
res2 = res.reshape((img.shape))

ret,thresh1 = cv2.threshold(res2,100,255,cv2.THRESH_BINARY_INV)
res3=cv2.bitwise_and(img1,img1,mask=thresh1)


#FOR CALYX

print('Type of the image : ' , type(res3))
cv2.imshow('res2',res3)
cv2.waitKey(0)
cv2.destroyAllWindows()





titles = ['Original Image','BINARY','BINARY_INV']
images = [img1,thresh1, closing,res,]
for i in range(4):
   # image = cv2.resize(images[i], (800, 600))
    cv2.imshow('hi',images[i])
    cv2.waitKey(0)
    cv2.destroyAllWindows() 