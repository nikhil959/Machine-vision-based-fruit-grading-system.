import cv2
import matplotlib.pyplot as plt
import numpy as np
import glob
import os


path = "C:/Users/Paavana Sanvi/Desktop/cleandata/*.*"
path1="C:/Users/Paavana Sanvi/Desktop/defect/"

imname='out'
suffix='.jpg'
i=0

for file in glob.glob(path):
    i+=1
    print(file)
   

    frame = cv2.imread(file)
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    print(hsv)

    # define range of blue color in HSV
    lower_blue =np.array ([27,0,0])
#print(lower_blue)
    upper_blue =np.array([255,255,255])

    # Threshold the HSV image to get only blue colors
    mask = cv2.inRange(hsv, lower_blue, upper_blue)

    # Bitwise-AND mask and original image
    res = cv2.bitwise_and(frame,frame, mask= mask)
    res = cv2.cvtColor(res, cv2.COLOR_BGR2GRAY)
    ret,thresh1 = cv2.threshold(res,10,255,cv2.THRESH_BINARY_INV)
    res3=cv2.bitwise_and(frame,frame,mask=thresh1)


    means, stddevs  = cv2.meanStdDev(res3)
    
    
    
    print(means)
    print(stddevs)
    fn=os.path.join(path1, imname + str(i)+suffix)
    cv2.imwrite(fn,res3)


    #cv2.imshow('hi',res3)
    #cv2.waitKey(0)
    #;l;la;lcv2.destroyAllWindows() 


