# -*- coding: utf-8 -*-
"""
Created on Mon Feb  4 20:37:19 2019

@author: Paavana Sanvi
"""

import numpy as np
import cv2
