# -*- coding: utf-8 -*-
"""
Created on Wed Apr 24 15:44:25 2019

@author: Paavana Sanvi
"""
import glob
import cv2
import numpy as np
import os
from skimage.feature import greycomatrix, greycoprops
from sklearn.metrics.cluster import entropy
import pickle
from sklearn.svm import SVC
#from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk

from tkinter import filedialog

main = tk.Tk()
main.geometry("900x400")
main.wm_title("Machine vision based fruit grading system")


main.filename =  filedialog.askopenfilename(initialdir = "/C:/Users/Paavana Sanvi/Desktop/appledata",title = "Select file",filetypes = (("jpeg files","*.jpg"),("all files","*.*")))


path=main.filename

#path = "Golden_14_1.jpg"
#path1=""
imname='out'
suffix='.jpg'
q=1
def meanstd(img):
            hsv_img=cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
            img_b= img[:,:,0]
            img_g=img[:,:,1]
            img_r=img[:,:,2]
            img_h=hsv_img[:,:,0]
    #mean
            mean_b = img_b[img_b!=0].mean()
            mean_g = img_g[img_g!=0].mean()
            mean_r = img_r[img_r!=0].mean()
            mean_h = img_h[img_h!=0].mean()
   #standard Deviation
            std_b=img_b[img_b!=0].std()
            std_g=img_g[img_g!=0].std()
            std_r=img_r[img_r!=0].std()
            std_h=img_h[img_h!=0].std()
   #appending values
            return [str(mean_b),str(mean_g),str(mean_r),str(mean_h),str(std_b),str(std_g),str(std_r),str(std_h)]


# Textural Features
# d = 1 at four directions,45, 90, 135, 180 degrees, because defected regions haveno spatial direction.
# extracted contrast, correlation,energy, homogeneity and entropy features
def glcmfeature(Img):
            Img_Gray = cv2.cvtColor(res3,cv2.COLOR_BGR2GRAY)
            def GLCM1(Img):
                hi=[]
                glcm = greycomatrix(Img, [1], [45,90,135,180],  symmetric=True, normed=True)
                a=(greycoprops(glcm, 'contrast'))
                for i in a:
                    for j in i:                  
                        hi.append(str(j))
        
                b=(greycoprops(glcm, 'homogeneity'))
                for i in b:
                    for j in i:
                        hi.append(str(j))
        
                c=(greycoprops(glcm, 'energy'))
                for i in c:
                    for j in i:
                        hi.append(str(j))
                d=(greycoprops(glcm, 'correlation'))
                for i in d:
                    for j in i:
                        hi.append(str(j))
                e=(entropy(res))
                hi.append(str(e))
                return hi
            GL=GLCM1(Img_Gray)
            return GL
        
        
def Geometric_Features(Img,threshz):
            geo=[]
            a=cv2.cvtColor(Img, cv2.COLOR_BGR2GRAY);
            ret,thresh = cv2.threshold(a,15,255,0)
            im2,contours,hierarchy = cv2.findContours(thresh, 1, 2)
            cnt = contours[0]
            x,y,w,h = cv2.boundingRect(cnt)
            # Defect Ratio
            ratio=w/h
            geo.append(str(ratio))
            # Media Axes Length
            a=cv2.countNonZero(thresh)
            b=cv2.countNonZero(threshz)
            r=(b/a)
            geo.append(str(r))
            # Perimeter
            perimeter = cv2.arcLength(cnt,True)
            geo.append(str(perimeter))
            return geo
for file in glob.glob(path):
    final=[]
  
    
    q+=1

    img= cv2.imread(file,0)
    img1= cv2.imread(file)
   # Background removal
    ret,thresh1 = cv2.threshold(img,15,255,cv2.THRESH_BINARY)
    ret,thresh2 = cv2.threshold(img,15,255,cv2.THRESH_BINARY_INV)
    kernel = np.ones((25,25),np.uint8)
    #stem_end outside
    closing = cv2.morphologyEx(thresh1, cv2.MORPH_OPEN, kernel)

    res=cv2.bitwise_and(img1,img1,mask=closing)
    # Calyx and Stem_end removal
    calyx=cv2.cvtColor(res, cv2.COLOR_BGR2YCrCb)
    
    Z = calyx[:,:,2].reshape((-1,3))
    Z = np.float32(Z)
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
    K = 2
    ret,label,center=cv2.kmeans(Z,K,None,criteria,10,cv2.KMEANS_RANDOM_CENTERS)
    
    # Now convert back into uint8, and make original image
    center = np.uint8(center)
    res = center[label.flatten()]
    res2 = res.reshape((img.shape))

    ret,thresh1 = cv2.threshold(res2,100,255,cv2.THRESH_BINARY_INV)
    res3=cv2.bitwise_and(img1,img1,mask=thresh1)
    
    bright = cv2.cvtColor(res3, cv2.COLOR_BGR2LAB)
    gray=cv2.cvtColor(res3,cv2.COLOR_BGR2GRAY)


#res=cv2.bitwise_and(img1,img1,mask=edges)
    Z = bright[:,:,1].reshape((-1,3))


    Z = np.float32(Z)


# define criteria, number of clusters(K) and apply kmeans()
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
    K = 3
    ret,label,center=cv2.kmeans(Z,K,None,criteria,10,cv2.KMEANS_RANDOM_CENTERS)

# Now convert back into uint8, and make original image
    center = np.uint8(center)
    res = center[label.flatten()]
    res2 = res.reshape((gray.shape))
    ret,thresh12 = cv2.threshold(res2,125,255,cv2.THRESH_BINARY)
    res31=cv2.bitwise_and(res3,res3,mask=thresh12)
    
    

    titles = ['Original Image','BINARY','BINARY_INV']
    images = [img,thresh1, closing,res3]
    #fn=os.path.join(path1, imname + str(q)+suffix)
   # cv2.imwrite(fn,res31)
    #print('out image is writtent',fn)
    
    
    imz=res31
    im=cv2.cvtColor(res31,cv2.COLOR_BGR2GRAY)
    ret,thresh1 = cv2.threshold(im,15,255,cv2.THRESH_BINARY)

    mask=np.zeros_like(im)
    _,contour,h=cv2.findContours(thresh1,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    c1=[]
    for c in contour:
        area=cv2.contourArea(c)
        if area>100:
           c1.append(c)
    
    cv2.drawContours(mask,c1,-1,(255,255,255),-1)
    out=np.zeros_like(thresh1)
        
              
    out[mask==255]=thresh1[mask==255]
    if(np.count_nonzero(out)==0):
        a=['0','0','0','0','0','0','0','0','0',
      '0','0','0','0','0','0','0','0','0',
      '0','0','0','0','0','0','0','0','0','0']
        for i in a:
            final.append(i)
  
        continue
    (x,y)=np.where(mask==255)
    (topx,topy)=(np.min(x),np.max(y))
    (bottomx,bottomy)=(np.max(x),np.max(y))
    out[topx:bottomx+1,topy:bottomy+1]=thresh1[topx:bottomx+1,topy:bottomy+1]

    res4=cv2.bitwise_and(imz,imz,mask=out)
    res3=res4
    

    textural=glcmfeature(res3)
    for i in textural:
        final.append(i)

    statistics=meanstd(res3)
    for i in statistics:
        final.append(i)

    geometric= Geometric_Features(res3,thresh1)
    for i in geometric:
        final.append(i)
    
   
    


loaded_model=pickle.load(open('svm_model.pkl','rb'))
feat=np.array(final)
feat=feat.reshape((1,len(feat)))
result = loaded_model.predict(feat)[0]
print(result)
print(final)






if(result==2):
     
    ourMessage ='Second Rank'
   
elif(result==1):
    ourMessage ='First Rank'
   
else:
    ourMessage ='Rejected'
    

main.wm_title("Machine vision based fruit grading system")
main.geometry("900x400")

label=tk.Label(main,text=ourMessage,font=('Berlin', 80, 'bold'))
label.pack(side="top",fill="x",pady=10)
B1=tk.Button(main,text="okay",width=40,height=3,fg='white',font=('times', 13, 'bold'),bg='black',command=main.destroy)
B1.pack()
main.mainloop( )
del path

#to display

images = [img1,res31,res4]


"""for i in range(3):
    image = cv2.resize(images[i], (800, 600))
    cv2.imshow('hi',image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()"""
    