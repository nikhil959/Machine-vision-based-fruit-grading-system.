# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 12:29:54 2019

@author: Paavana Sanvi
"""

import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread('out74.jpg',0)
img1 = cv2.imread('out74.jpg')
bright = cv2.cvtColor(img1, cv2.COLOR_BGR2LAB)


#res=cv2.bitwise_and(img1,img1,mask=edges)
Z = bright[:,:,1].reshape((-1,3))


Z = np.float32(Z)


# define criteria, number of clusters(K) and apply kmeans()
criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
K = 3
ret,label,center=cv2.kmeans(Z,K,None,criteria,10,cv2.KMEANS_RANDOM_CENTERS)

# Now convert back into uint8, and make original image
center = np.uint8(center)
res = center[label.flatten()]
res2 = res.reshape((img.shape))

ret,thresh1 = cv2.threshold(res2,125,255,cv2.THRESH_BINARY)
res3=cv2.bitwise_and(img1,img1,mask=thresh1)

titles = ['OriginalImage','BINARY']

images = [img1,bright[:,:,1],res2,res3]

for i in range(4):
   # image = cv2.resize(images[i])
    cv2.imshow('hi',images[i])
    cv2.waitKey(0)
    cv2.destroyAllWindows()